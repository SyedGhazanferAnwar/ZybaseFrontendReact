import React, { Component } from 'react';

class settingsPanel extends Component {
    state = {  }
    render() { 
        return ( <ReactFragment>
            
        </ReactFragment>  );
    }
}
 
export default settingsPanel;
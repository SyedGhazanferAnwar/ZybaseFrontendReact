import React, { Component } from "react";
class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return <h1>DASHBOARD</h1>;
  }
}

export default Dashboard;
